/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employee;

/**
 *
 * @author Reem Aljohar
 */
public class Employee {

    public static void main(String[] args) {
      
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Fatimah Aljohar", "Manager", 50000, 7, "Bachelor Degree");
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Jawaher Aljohar", "IT Support Officer", 30000, 3, "Diploma");

        System.out.println("Full Time Employee:");
        System.out.println("Name: " + fullTimeEmployee.getName());
        System.out.println("Position: " + fullTimeEmployee.getPosition());
        System.out.println("Salary: " + fullTimeEmployee.calculateSalary());
        System.out.println("Bonus: " + fullTimeEmployee.calculateBonus());

        System.out.println("\nPart Time Employee:");
        System.out.println("Name: " + partTimeEmployee.getName());
        System.out.println("Position: " + partTimeEmployee.getPosition());
        System.out.println("Salary: " + partTimeEmployee.calculateSalary());
        System.out.println("Bonus: " + partTimeEmployee.calculateBonus()); 
        
    }
}
