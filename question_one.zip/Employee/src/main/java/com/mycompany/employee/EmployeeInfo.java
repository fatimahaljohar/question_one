/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Reem Aljohar
 */
public abstract class EmployeeInfo {
   
    private String name;
    private String position;
    private double basicSalary;
    private int experience;
    private String educationalLevel;

    public EmployeeInfo(String name, String position, double basicSalary, int experience, String educationalLevel) {
        this.name = name;
        this.position = position;
        this.basicSalary = basicSalary;
        this.experience = experience;
        this.educationalLevel = educationalLevel;
    }

    public abstract double calculateSalary();

    public abstract double calculateBonus();

    // Getters and setters
    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public int getExperience() {
        return experience;
    }

    public String getEducationalLevel() {
        return educationalLevel;
    }
}

    

