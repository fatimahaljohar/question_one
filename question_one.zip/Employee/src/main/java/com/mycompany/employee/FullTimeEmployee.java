/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Reem Aljohar
 */
public class FullTimeEmployee extends EmployeeInfo{
 
    
    public FullTimeEmployee(String name, String position, double basicSalary, int experience, String educationalLevel) {
        super(name, position, basicSalary, experience, educationalLevel);
    }

    @Override
    public double calculateSalary() {
        double baseSalary = getBasicSalary();
        double experienceBonus = baseSalary * 0.05 * getExperience();
        double educationBonus = 0;

        if (getEducationalLevel().equalsIgnoreCase("Bachelor Degree")) {
            educationBonus = 500;
        } else if (getEducationalLevel().equalsIgnoreCase("Diploma")) {
            educationBonus = 250;
        }

        return baseSalary + experienceBonus + educationBonus;
    }

    @Override
    public double calculateBonus() {
        return getBasicSalary() * 0.03;
    }

    
}
